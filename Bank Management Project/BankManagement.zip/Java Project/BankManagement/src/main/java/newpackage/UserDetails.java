/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;
import java.util.Scanner;
import java.io.*;
import javax.swing.JOptionPane;
import newpackage.Credentials;
/**
 *
 * @author vishakan
 */
class PANException extends Exception{
    String PAN;
    PANException(String PAN){
        this.PAN=PAN;
    }
    public String toString(){
        return "The PAN "+this.PAN+" is already linked to another account!";
    }
}

public class UserDetails {
    private int key;
    private String name;
    private String address;
    private String PAN;
    private int age;
    private boolean savings,fixed,loan;
    
    public UserDetails(int key, String name, String address, int age, String PAN,  boolean savings, boolean fixed, boolean loan){
        this.key=key;
        this.name=name;
        this.address=address;
        this.PAN=PAN;
        this.age=age;
        this.savings=savings;
        this.fixed=fixed;
        this.loan=loan;
    }

    UserDetails() {
        this.key=-1;        //for returning a negative key value for a non-initialised user
    }
    
    public int getKey(){
        return key;
    }
    
    public String getName(){
            return name;
    }
    
    public String getAddress(){
        return address;
    }
    
    public String getPAN(){
        return PAN;
    }
    
    public int getAge(){
        return age;
    }
    
    public boolean getSavings(){
        return savings;
    }
    
    public boolean getFixed(){
        return fixed;
    }
    
    public boolean getLoan(){
        return loan;
    }
    
    public void setKey(int key){
        this.key=key;
    }
    
    public void setName(String name){
        this.name=name;
    }
    
    public void setAddress(String address){
        this.address=address;
    }
   
    public void setPAN(String PAN){
        this.PAN=PAN;
    }
    
    public void setAge(int age){
        this.age=age;
    }
    
    public void setFixed(boolean fixed){
        this.fixed=fixed;
    }
    
    public void setSavings(boolean savings){
        this.savings=savings;
    }
    
    public void setLoan(boolean loan){
        this.loan=loan;
    }
    
    public boolean UserDetailsWriter(UserDetails u) throws IOException,PANException{
        UserDetails temp = new UserDetails();
        temp=temp.UserDetailsReader(u.getKey());     //checking whether a user already exists with the specified Key Value
        if(temp.getKey()!=-1)       //returning false boolean value if user exists with specified key value
            return false;
        
        if(u.PANChecker(u.getPAN())==false){
            throw new PANException(u.getPAN());
        }
        else{
            FileWriter fw= new FileWriter("userdetails.txt",true);
            fw.write(u.getKey()+"\t"+u.getName()+"\t"+u.getAddress()+"\t"+u.getAge()+"\t"+u.getPAN()+"\t"+u.getSavings()+"\t"+u.getFixed()+"\t"+u.getLoan()+"\n");
            fw.close();
            return true;
        }
    }
    
    public UserDetails UserDetailsReader(int key) throws FileNotFoundException{
        File f = new File("userdetails.txt");
        Scanner s = new Scanner(f);
        UserDetails u = new UserDetails();
        s.useDelimiter("\t");
        
        while(s.hasNextLine()){
            int ukey=s.nextInt();
            if(ukey==key){
                u.setKey(ukey);
                u.setName(s.next());
                u.setAddress(s.next());
                u.setAge(Integer.parseInt(s.next()));
                u.setPAN(s.next());
                u.setSavings(s.nextBoolean());
                u.setFixed(s.nextBoolean());
                boolean temp=false;
                if(s.nextLine().contains("true"))
                    temp=true;
                u.setLoan(temp);
                break;
            }
            else
                s.nextLine();
        }
        s.close();
        return u;       //Returns valid UserDetails Object if User Exists, otherwise Null Record with Key Value -1 is Returned.
        
    }
    
    public boolean PANChecker(String PAN) throws FileNotFoundException{
        File f = new File("userdetails.txt");
        Scanner s = new Scanner(f);
        s.useDelimiter("\t");
        if(PAN.equals("N/A"))
            return true;    //since many users may have No PAN card attached
        while(s.hasNextLine()){
            s.next();       //skipping key
            s.next();       //skipping name
            s.next();       //skipping address
            s.next();       //skipping age
            String filePAN=s.next();
            if(filePAN.equals(PAN)){
                return false;       //PAN CARD ALREADY EXISTS
            }
            else
                s.nextLine();
        }
        s.close();
        return true;        //PAN CARD IS UNIQUE
    }
    
    public boolean UserDetailsUpdater(UserDetails u) throws FileNotFoundException, IOException{
        File f1 = new File("userdetails.txt");
        Scanner s = new Scanner(f1);
        FileWriter fw= new FileWriter("temp.txt",true);
        s.useDelimiter("\t");
        UserDetails t = new UserDetails();
        
        
        while(s.hasNextLine()){
            t.setKey(s.nextInt());
            t.setName(s.next());
            t.setAddress(s.next());
            t.setAge(Integer.parseInt(s.next()));
            t.setPAN(s.next());
            t.setSavings(s.nextBoolean());
            t.setFixed(s.nextBoolean());
            t.setLoan(Boolean.parseBoolean(s.nextLine()));
            //System.out.println(t.getKey()+" "+t.getName()+" "+t.getAddress()+" "+t.getAge()+" "+t.getPAN()+" "+t.getSavings()+" "+t.getFixed()+" "+t.getLoan());
            if(t.getKey()!=u.getKey()){
                fw.write(t.getKey()+"\t"+t.getName()+"\t"+t.getAddress()+"\t"+t.getAge()+"\t"+t.getPAN()+"\t"+t.getSavings()+"\t"+t.getFixed()+"\t"+t.getLoan()+"\n");                
            }
            else{
                 fw.write(u.getKey()+"\t"+u.getName()+"\t"+u.getAddress()+"\t"+u.getAge()+"\t"+u.getPAN()+"\t"+u.getSavings()+"\t"+u.getFixed()+"\t"+u.getLoan()+"\n");
            }
            //System.out.println(s.nextLine());
        }
        s.close();
        fw.close();
        
        File f2 = new File("temp.txt");
        f1.delete();
        f2.renameTo(f1);
        return true;   
    }
    
    /*public static void main(String args[]){
        UserDetails u = new UserDetails(2,"Vikram Nara","Vadapalani",22,"ABCDEF",true,false,false);
        try{
            u.UserDetailsUpdater(u);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }*/
}