/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package newpackage;

/**
 *
 * @author vishakan
 */

import java.util.*;
import java.io.File;
import java.io.*;

class MinBalanceException extends Exception{
	public String toString(){
		return "\nWithdrawing of this amount leads to balance less than 1000";
	}
}
class PANrequiredException extends Exception{
	public String toString(){
		return "\nPAN Number required for Withdrawing of amount greater than Rs.50,000";
	}
}
class MinBalanceRequiredException extends Exception{
	public String toString(){
		return "\nMinimum Balance of  Rs.1000 is Reqiured";
	}
}
public class Savings {
	private double current,debit,credit,pre;
	private int key;
        
        Savings(){
        }
        
        Savings(int key, double curr){
            this.key=key;
            this.current=curr;
            this.credit=0;
            this.debit=0;
            this.pre=0;
        }
        
        public int getKey(){
            return key;
        }
	
	public double getPre(){
		return pre;
	}
	
	public double getCurrent(){
		return current;
	}
	public double getDebit(){
		return debit;
	}
	public double getCredit(){
		return credit;
	}
	
        public void setKey(int key){
            this.key=key;
        }
	
	public void setCurrent(double amt){
		this.current=amt;
	}
	public void setDebit(double amt){
		this.debit=amt;
	}
	
	public void setCredit(double amt){
		this.credit=amt;
	}
	
	
	public void setPre(double amt){
		this.pre=amt;
	}
	public void displayDetails(Savings s){
                System.out.println("\n"+s.getKey()+"\t\t"+s.getPre()+"\t\t"+s.getCredit()+"\t\t\t"+s.getDebit()+"\t\t\t"+s.getCurrent()+"\n");		
	}
	
	
        public Savings calcBalance(int opt,Savings s,double amt) throws PANrequiredException,MinBalanceException {
		double current,debit,credit;
		if(opt==1){
			if(s.getCurrent()-amt<1000){
				throw new MinBalanceException();
			}
			else{
				s.setPre(s.getCurrent());
				s.setDebit(amt);
				s.setCurrent(s.getCurrent()-s.getDebit());
				return s;


			}
		}
		else if(opt==2){
			if(amt> 50000){
                                if(Login.u.getPAN().equals("N/A"))
                                    throw new  PANrequiredException();
			}
			s.setPre(s.getCurrent());
			s.setCredit(amt);
			s.setCurrent(s.getCurrent()+s.getCredit());
			return s;

		}
                else{
                    
                }
		return s;
	}
   
	public  Savings SavingsReader(int key) throws FileNotFoundException{
      		Savings sa =new Savings();
        	
        	try{
        	FileReader f = new FileReader("savings.txt");
        	Scanner s = new Scanner(f);
        	s.useDelimiter("\t");
        	while(s.hasNextLine()){
        	    int ukey=s.nextInt();
        	    if(ukey==key){
        	    
        	        sa.setKey(ukey);
        	        sa.setPre(Double.parseDouble(s.next()));
        	        sa.setDebit(Double.parseDouble(s.next()));
        	        sa.setCredit(Double.parseDouble(s.next()));
        	        sa.setCurrent(Double.parseDouble(s.nextLine()));
        	        break;
        	    }
        	    else
        	        s.nextLine();
        	}
        	s.close();
        	}
        	catch(Exception e){
        		System.out.println(e);
        	}
        	return sa;
	}
	public void SavingsFileUpdater(Savings sa1) throws Exception{
		double pre,credit,debit,curr;
		int ukey;
		Savings sa =new Savings();
		Savings temp =new Savings();
		File f=new File("savings.txt");
		try{
				
			FileWriter t=new FileWriter("temp.txt",true);
			Scanner s = new Scanner(f);
			s.useDelimiter("\t");
        		while(s.hasNextLine()){
        			temp.setKey(s.nextInt());
        			temp.setPre(Double.parseDouble(s.next()));
        			temp.setCredit(Double.parseDouble(s.next()));
        			temp.setDebit(Double.parseDouble(s.next()));
        			temp.setCurrent(Double.parseDouble(s.nextLine()));
        			if(sa1.getKey()!=temp.getKey()){
        				t.write(temp.getKey()+"\t"+temp.getPre()+"\t"+temp.getDebit()+"\t"+temp.getCredit()+"\t"+temp.getCurrent()+"\n");
        			}
        			else{
        				t.write(sa1.getKey()+"\t"+sa1.getPre()+"\t"+sa1.getDebit()+"\t"+sa1.getCredit()+"\t"+sa1.getCurrent()+"\n");
        			}
        		}
        		t.close();
        		s.close();
        	}
        	catch(Exception e){
			System.out.println(e);
		}
		File f2 = new File("temp.txt");
      		f.delete();
        	f2.renameTo(f);
	}
        
        public boolean SavingsWriter(Savings sa) throws Exception{
		try{
			FileWriter t=new FileWriter("savings.txt",true);
                        t.write(sa.getKey()+"\t"+sa.getPre()+"\t"+sa.getDebit()+"\t"+sa.getCredit()+"\t"+sa.getCurrent()+"\n");
                        t.close();
        	}
        	catch(Exception e){
			System.out.println(e);
                        return false;
		}
                return true;
        }
}


