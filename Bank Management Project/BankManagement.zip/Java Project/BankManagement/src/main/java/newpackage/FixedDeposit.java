/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author vishakan
 */
public class FixedDeposit {
    private int key;
    private double interest;
    private double maturity_val;
    private double principal;
    private double rate_of_interest;
    private double comp_yrs;
    
    FixedDeposit(){}
    
    FixedDeposit(int key, double intr, double mval, double prin, double rate, double yrs){
        this.key=key;
        interest=intr;
        maturity_val=mval;
        principal=prin;
        rate_of_interest=rate;
        comp_yrs=yrs;
    }
    
    public void setKey(int key)
    {
        this.key=key;
    }
    
    
    public int getKey()
    {
        return this.key;
    }
    
    public double getInterest()
    {
        return this.interest;
    }
    
    public void setInterest(double interest)
    {
        this.interest=interest;
    }
    
    public double getMaturity_val()
    {
        return this.maturity_val;
    }
    
    public void setMaturity_val(double maturity_val)
    {
        this.maturity_val=maturity_val;
    }
    
    public double getPrincipal()
    {
        return this.principal;
    }
    
    public void setPrincipal(double principal)
    {
        this.principal=principal;
    }
    
    public double getRate_of_interest()
    {
        return rate_of_interest;
    }
    
    public void setRate_of_interest(double rate_of_interest)
    {
        this.rate_of_interest=rate_of_interest;
    }
    
    public double getComp_yrs()
    {
        return this.comp_yrs;
    }
    
    public void setComp_yrs(double comp_yrs)
    {
        this.comp_yrs=comp_yrs;
    }
    
    public FixedDeposit KeyReader(int key) throws FileNotFoundException{
        File f = new File("userdetails.txt");
        Scanner s = new Scanner(f);
        FixedDeposit u = new FixedDeposit();
        u.setKey(-1);
        s.useDelimiter("\t"); 
        while(s.hasNextLine()){
            int ukey=s.nextInt();
            if(ukey==key){
                u.setKey(ukey);
                break;
            }
            else
                s.nextLine();
        }
        s.close();
        return u;
    }
   
    public boolean FixedDepositWriter(FixedDeposit u) throws IOException //WRITES TO THE FILE
    {
        FileWriter fw= new FileWriter("fixeddeposit.txt",true);
	//System.out.println(u.getKey()+u.getPrincipal()+u.getRate_of_interest()+u.getComp_yrs()+u.getMaturity_val());
        fw.write(u.getKey()+"\t"+u.getPrincipal()+"\t"+u.getRate_of_interest()+"\t"+u.getInterest()+"\t"+u.getComp_yrs()+"\t"+u.getMaturity_val()+"\n");
        fw.close();
        return true;
    }
    
    public FixedDeposit FixedReader(int key) throws FileNotFoundException{
        File f = new File("fixeddeposit.txt");
        FixedDeposit t = new FixedDeposit();
        Scanner s = new Scanner(f);
        FixedDeposit fd = new FixedDeposit();
        fd.setKey(-1);
        s.useDelimiter("\t");
        while(s.hasNextLine()){
            t.setKey(Integer.parseInt(s.next()));
            t.setPrincipal(Double.parseDouble(s.next()));
            t.setRate_of_interest(Double.parseDouble(s.next()));
            t.setInterest(Double.parseDouble(s.next()));
            t.setComp_yrs(Double.parseDouble(s.next()));
            t.setMaturity_val(Double.parseDouble(s.nextLine()));
            //System.out.println(t.getKey()+" "+t.getPrincipal()+" "+t.getRate_of_interest()+" "+t.getComp_yrs()+" "+t.getMaturity_val());
            if(t.getKey()==key){
                fd=t;
                break;
                //System.out.println(fd.getKey()+" "+fd.getPrincipal()+" "+fd.getRate_of_interest()+" "+fd.getComp_yrs()+" "+fd.getMaturity_val());
            }
        }
        return fd;
    }
}
