/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author vishakan
 */

class LowAmountException extends Exception{
    public String toString(){
		return "\nMinimum Loan Amount is Rs.100000.\nPlease enter an amount of Rs.100000 or above.";
	}
}

public class Loan {
    
    private String name;
    private int key;
    private double interest; 
    private double prin_amt;
    private double yrs;
    private double anual_pay1;
    private double anual_pay2;
    private double anual_pay3;
    private double total_amt;
    private String type;
    
    Loan(){}
    
    Loan(int key, double prin_amt, String type){
        this.key=key;
        this.prin_amt=prin_amt;
        this.type=type;
    }
    
    public double getTotal_amt()
    {
        return this.total_amt;
    }
    
    public void setTotal_amt(double total_amt)
    {
        this.total_amt=total_amt;
    }
            
    public void setKey(int key)
    {
        this.key=key;
    }
    
    public void setInterest(double interest)
    {
        this.interest=interest;
    }
    
    public void setPrin_amt(double prin_amt)
    {
        this.prin_amt=prin_amt;
    }
    
    public void setYrs(double yrs)
    {
        this.yrs=yrs;
    }
    
    public void setAnual_pay1(double anual_pay1)
    {
        this.anual_pay1=anual_pay1;
    }
    
    public void setAnual_pay2(double anual_pay2)
    {
        this.anual_pay2=anual_pay2;
    }
    
    public void setType(String type){
        this.type=type;
    }
    
    public void setAnual_pay3(double anual_pay3)
    {
        this.anual_pay3=anual_pay3;
    }
    
    public String getType(){
        return this.type;
    } 
    
    public int getKey()
    {
        return this.key;
    }
    
     public double getInterest()
    {
        return this.interest;
    }
    
    public double getPrin_amt()
    {
        return this.prin_amt;
    }
    
     public double getYrs()
    {
        return this.yrs;
    }
       
    public double getAnual_pay1()
    {
        return this.anual_pay1;
    }
    
    public double getAnual_pay2()
    {
        return this.anual_pay2;
    }
    public double getAnual_pay3()
    {
        return this.anual_pay3;
    }
    
     public Loan UserDetailsReader(int key) throws FileNotFoundException{
        File f = new File("userdetails.txt");
        Scanner s = new Scanner(f);
        Loan u = new Loan();
        s.useDelimiter("\t"); 
        while(s.hasNextLine()){
            int ukey=s.nextInt();
            if(ukey==key){
                u.setKey(ukey);
                u.setType(s.next());
                break;
            }
            else
                s.nextLine();
        }
        s.close();
        return u;
    }
     
    public boolean LoanWriter(Loan u) throws IOException //WRITES TO THE FILE
    {
        FileWriter fw= new FileWriter("loan.txt",true);
	//System.out.println(u.getKey()+u.getType()+getPrin_amt()+u.getInterest()+u.getYrs()+u.getAnual_pay1()+u.getAnual_pay2()+u.getAnual_pay3()+u.getTotal_amt());
        fw.write(u.getKey()+"\t"+u.getType()+"\t"+getPrin_amt()+"\t"+u.getInterest()+"\t"+u.getYrs()+"\t"+u.getAnual_pay1()+"\t"+u.getAnual_pay2()+"\t"+u.getAnual_pay3()+"\t"+u.getTotal_amt()+"\n");
        fw.close();
        return true;
    }
    
    public double intr(double princ,double eqinstal)
 {
     double prinunpaid;
     prinunpaid=princ-eqinstal;
     return prinunpaid;
 }
    
    public Loan LoanCalculator(Loan s,double prin_amt,int ch) throws LowAmountException
 {
     
    
    double interest;
    double int1;
    double int2;
    double int3;
    double yrs;
    double pay1,pay2,pay3;
    double equinstal;
    Loan u=new Loan();
    double anual_pay1;
    double anual_pay2;
    double anual_pay3;
    double unpaid1,unpaid2,unpaid3;
    double temp;
    equinstal=prin_amt/3;
    double total;
    
    if(prin_amt<100000)
        throw new LowAmountException();

     if(ch==1)          //HOUSING LOAN
     {
        s.setInterest(10);
        s.setYrs(3);
        int1=prin_amt*0.1;
        pay1=equinstal+int1;
        pay1 = Math.round(pay1 * 100.0) / 100.0;
        s.setAnual_pay1(pay1);
        
        unpaid2=u.intr(prin_amt,equinstal);
        int2=unpaid2*0.1;
        pay2=equinstal+int2;
        pay2 = Math.round(pay2 * 100.0) / 100.0;
        s.setAnual_pay2(pay2);
        
        unpaid3=u.intr(unpaid2,equinstal);
        int3=unpaid3*0.1;
        pay3=equinstal+int3;
        pay3 = Math.round(pay3 * 100.0) / 100.0;
        s.setAnual_pay3(pay3);
        total=pay1+pay2+pay3;
        total = Math.round(total * 100.0) / 100.0;
        s.setTotal_amt(total);
     }
     else if(ch==2)     //VEHICLE LOAN
     {
       s.setInterest(7);
       s.setYrs(3);
       unpaid1=u.intr(prin_amt,equinstal);
       int1=unpaid1*0.07;
       pay1=equinstal+int1;
       pay1 = Math.round(pay1 * 100.0) / 100.0;
       s.setAnual_pay1(pay1);
        
       unpaid2=u.intr(unpaid1,equinstal);
       int2=unpaid2*0.07;
       pay2=equinstal+int2;
       pay2 = Math.round(pay2 * 100.0) / 100.0;
       s.setAnual_pay2(pay2);
        
       unpaid3=u.intr(unpaid2,equinstal);
       int3=unpaid3*0.07;
       pay3=equinstal+int3;
       pay3 = Math.round(pay3 * 100.0) / 100.0;
       s.setAnual_pay3(pay3);
       total=pay1+pay2+pay3;
       total = Math.round(total * 100.0) / 100.0;
        s.setTotal_amt(total);
        
        
     }
      
     
     else{
     }
     
     return s;
 }
    
    public  Loan LoanReader(int key) throws FileNotFoundException{
      		Loan l = new Loan();
        	
        	try{
        	FileReader f = new FileReader("loan.txt");
        	Scanner s = new Scanner(f);
        	s.useDelimiter("\t");
        	while(s.hasNextLine()){
        	    int ukey=s.nextInt();
        	    if(ukey==key){
                        //fw.write(u.getKey()+"\t"+u.getType()+"\t"+getPrin_amt()+"\t"+u.getInterest()+"\t"+u.getYrs()+"\t"+u.getAnual_pay1()+"\t"+u.getAnual_pay2()+"\t"+u.getAnual_pay3()+"\t"+u.getTotal_amt()+"\n");
        	        l.setKey(ukey);
        	        l.setType(s.next());
        	        l.setPrin_amt(s.nextDouble());
        	        l.setInterest(s.nextDouble());
        	        l.setYrs(s.nextDouble());
                        l.setAnual_pay1(s.nextDouble());
                        l.setAnual_pay2(s.nextDouble());
                        l.setAnual_pay3(s.nextDouble());
                        l.setTotal_amt(Double.parseDouble(s.nextLine()));
        	        break;
        	    }
        	    else
        	        s.nextLine();
        	}
        	s.close();
        	}
        	catch(Exception e){
        		System.out.println(e);
        	}
        	return l;
	}
   
}
    
