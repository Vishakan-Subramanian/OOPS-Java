/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author vishakan
 */
public class Credentials {
    private String name;
    private int key;
    private int pin;
    
    public Credentials(){
        this.key=-1;
    }
    
    public Credentials(int key, String name, int pin){
        this.key=key;
        this.name=name;
        this.pin=pin;
    }
    
    public String getName(){
        return this.name;
    }
    
    public int getPIN(){
        return this.pin;
    }
    
    public int getKey(){
        return this.key;
    }
    
    public void setName(String name){
        this.name=name;
    }
    
    public void setKey(int key){
        this.key=key;
    }
    
    public void setPIN(int pin){
        this.pin=pin;
    }
    
    public void CredentialsWriter(Credentials c) throws IOException{
        FileWriter fw= new FileWriter("credentials.txt",true);
        fw.write(c.getKey()+"\t"+c.getName()+"\t"+c.getPIN()+"\t\n");
        fw.close();
    }
    
    public int CredentialsChecker(Credentials c) throws FileNotFoundException{
        Credentials temp = new Credentials();
        File f = new File("credentials.txt");
        Scanner s = new Scanner(f);
        UserDetails u = new UserDetails();
        s.useDelimiter("\t");
        boolean uflag=false,pflag=false;
        
        while(s.hasNextLine()){
                temp.setKey(s.nextInt());
                temp.setName(s.next());
                if(temp.getName().equals(c.getName())){
                    uflag=true;
                    temp.setPIN(Integer.parseInt(s.next()));
                    if(temp.getPIN()==c.getPIN()){
                        pflag=true;
                        break;     //User Key is returned in both match case
                    }
                    else
                        s.nextLine();
                }
                else
                    s.nextLine();
        }
        s.close();
        if(uflag==false && pflag==false)
            return -1;              // -1 is returned if both username and password do not exist
        else if(uflag==true && pflag==false)
            return 0;               //0 is returned only if username is matched and password is incorrect
        else
            return temp.getKey();       //Key is returned if both match
    }
    
}
